#ifndef UTILS_H
#define UTILS_H

const char * const_input();

#endif