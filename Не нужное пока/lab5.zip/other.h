
//Прототипы используемых в данном задании функций:

void sort(char* pcFirst, int nNumber, int size,
     void (*Swap)(void*, void*), int (*Compare)(void*, void*) );
void swap_int(void* p1, void* p2);
int cmp_int(void* p1, void* p2);

